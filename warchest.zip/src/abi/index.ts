export { abi as meowContractABI } from "./meowContract.json";
export { abi as NFTContractABI } from "./NFTcontract.json";
export { abi as meowTokenContract } from "./neowTokenContract.json";