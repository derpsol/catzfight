export const getMainnetURI = (): string => {
    return "https://ethereum-goerli-rpc.allthatnode.com";
    return "https://api.avax.network/ext/bc/C/rpc";
};
