declare module '@intercroneswap/tronlink-provider';
